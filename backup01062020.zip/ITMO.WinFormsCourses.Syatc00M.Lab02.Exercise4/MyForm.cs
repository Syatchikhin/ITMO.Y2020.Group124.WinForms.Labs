﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ITMO.CSCourses2020.Syatc00M.Lab02.Exercise4
{
    public partial class MyForm : Form
    {
        public MyForm()
        {
            InitializeComponent();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ITMO._2020.WF.SyatcM.ExamTask.GasProp
{
    public partial class MainForm : Form
    {
        public string path;

        //public double mixtureDencity
        //{
        //    get { return mixtureDencity; }
        //    set { mixtureDencity = value; }
        //}


        public MainForm()
        {
            InitializeComponent();
        }

        List<GasComposition> myGas = new List<GasComposition>();

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        public void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //--clean previous data----
            gasNameTextBox.Text = gasConstantTextBox.Text = dencityTextBox.Text = "";
            //gasConstantTextBox.Text = "";
            //dencityTextBox.Text = "";
            gasListView.Items.Clear(); //clear screen 
            myGas.Clear(); //clear gas 
            //-----------------
            Stream myStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = @"C:\temp";
           // openFileDialog1.Filter = "xlsx files (*.xlsx)|*.xlsx|All Files(*.*)|*.*";
            openFileDialog1.Filter = "xlsx files (*.xlsx)|*.xlsx";
            openFileDialog1.FilterIndex = 2;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((myStream = openFileDialog1.OpenFile()) != null)
                    {
                        path = openFileDialog1.FileName;
                        GasComposition myGas1 = new GasComposition();
                        GasComposition myGas1Composition = GasComposition.ReadExcelFile(ref path, ref myGas1);

                        gasNameTextBox.Text = myGas1Composition.gasName;//gas name
                        
                        MainForm mainmenu = new MainForm();//fill the screen
                        for (int j = 0; j < myGas1Composition.size; j++)// по всем строкам
                        {
                            ListViewItem newItem = gasListView.Items.Add((j+1).ToString());
                             //newItem = gasListView.Items.Add((j + 1).ToString());
                            newItem.SubItems.Add(myGas1Composition.componentName[j]);
                            newItem.SubItems.Add(myGas1Composition.componentFormula[j]);
                            newItem.SubItems.Add(myGas1Composition.componentData[j, 0].ToString());
                            newItem.SubItems.Add(myGas1Composition.componentData[j, 1].ToString());
                            newItem.SubItems.Add((myGas1Composition.componentWeight[j].ToString()));
                        }

                        myGas.Add(myGas1); //send gas to collection
                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk:" + ex.Message);
                }

            }

        }

        public void рассчитатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (gasNameTextBox.Text != "") //protection from empty calculation
            { GasComposition myTempGas = myGas[0]; //extract gas from collection
            GasComposition myGas1NormalizedComposition = GasComposition.Normalize(ref myTempGas); //normalize
            GasComposition myGas1Calculated = GasComposition.CalculateProperties(ref myGas1NormalizedComposition); //calc prop
            // send RO and R to screen
            dencityTextBox.Text = myGas1Calculated.mixtureDencity.ToString();
            gasConstantTextBox.Text = myGas1Calculated.mixtureR.ToString(); 
            }
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //gasNameTextBox.Text = "";
            //gasConstantTextBox.Text = "";
            //dencityTextBox.Text = "";
            gasNameTextBox.Text = gasConstantTextBox.Text = dencityTextBox.Text = "";
            gasListView.Items.Clear(); //clear screen 
            myGas.Clear(); //clear gas 
        }
    }
}
